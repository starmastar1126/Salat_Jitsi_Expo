package com.reactnativejitsimeet;

public interface IRNJitsiMeetViewReference {
    public void setJitsiMeetView(RNJitsiMeetView jitsiMeetView);

    public RNJitsiMeetView getJitsiMeetView();
}
