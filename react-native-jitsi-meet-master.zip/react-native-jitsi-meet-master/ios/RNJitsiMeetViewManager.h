#import <React/RCTViewManager.h>
#import <JitsiMeet/JitsiMeetViewDelegate.h>

@interface RNJitsiMeetViewManager : RCTViewManager <JitsiMeetViewDelegate>
@end